package com.example.sicetcrud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.sicetcrud.entity.Student;
import com.example.sicetcrud.repository.StudentRepo;


// CURD Operations
@Service
public class StudentService {
	
	@Autowired
	private StudentRepo srepo;
	
	// inserting data
	public Student addStud(Student s) {
		return srepo.save(s);
	}
		
	// Get Data
		public List<Student>  getStud(){
			return srepo.findAll();
		}
	
	// Update data	
			// update set college="sicet" where id=101;
			public Student updateStud(Student s) {
				Integer id=s.getId();
				// getId-->student input
				//findById-->Database input
				Student s1=srepo.findById(id).get();
			s1.setName(s.getName());
			s1.setCollege(s.getCollege());
			s1.setRoll(s.getRoll());
			s1.setQualification(s.getQualification());
			s1.setCourse(s.getCourse());
			s1.setYear(s.getYear());
			s1.setCertificate(s.getCertificate());
			s1.setHallticketno(s.getHallticketno());
			return srepo.save(s1);
			
		}
		// Delete 
			public void deleteStud(int id) {
				srepo.deleteById(id);
			}
	}