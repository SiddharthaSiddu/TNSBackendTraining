package com.example.sicetcrud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.sicetcrud.entity.Student;
import com.example.sicetcrud.service.StudentService;

@RestController
public class Controller {
	
	@Autowired
	private StudentService sserv;
	
	//adding data
	@PostMapping("/addstudent")
	public Student regStudent(@RequestBody Student s) {
		return sserv.addStud(s);
	}
		
		//Get Data
		@GetMapping("/getstudent")
		public List<Student>  getStudent(){
			return sserv.getStud();
		}
		
		// update
		@PutMapping("/updatestudent")
		public Student updateStudent(@RequestBody Student s) {
			return sserv.updateStud(s);
	}
		// delete
		@DeleteMapping("/deletestudent/{id}")
		public void deleteStudent(@PathVariable Integer id) {
			sserv.deleteStud(id);
		}

}