package com.example.sicetcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SicetcrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(SicetcrudApplication.class, args);
	}

}
